﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases
{
    public static class AccesoDatos
    {
        private static string cadenaConexion;
        private static SqlCommand comando;
        private static SqlConnection conexion;

        static AccesoDatos()
        {
            cadenaConexion = @"Data Source=LIBW102X3T\SQLEXPRESS;
                                 Initial Catalog=20240701-SP;
                                 Integrated Security=True";
            comando = new SqlCommand();
            conexion = new SqlConnection(cadenaConexion);
            comando.CommandType = System.Data.CommandType.Text;
            comando.Connection = conexion;
        }

        public static void ActualizarSerie(Serie serie)
        {
            try
            {
                comando.Parameters.Clear();
                conexion.Open();
                comando.CommandText = $"UPDATE series SET alumno = @alumno WHERE genero = @genero AND nombre = @nombre ";
                comando.Parameters.AddWithValue("@alumno", "Gonzalo Ceballos");
                comando.Parameters.AddWithValue("@Nombre", serie.Nombre);
                comando.Parameters.AddWithValue("@genero", serie.Genero);
                comando.ExecuteNonQuery();
            } catch (Exception ex)
            {
                throw ex;
            } finally
            {
                conexion.Close();
            }
        }
        public static List<Serie> ObtenerBackLog()
        {
            List<Serie> listaSeries = new List<Serie>();
            try
            {
                comando.Parameters.Clear();
                conexion.Open();
                comando.CommandText = $"SELECT * FROM series";
                comando.ExecuteNonQuery();

                using (SqlDataReader reader = comando.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        listaSeries.Add(new Serie(reader["genero"].ToString(), reader["nombre"].ToString()));
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return listaSeries;
        }

    }
}
