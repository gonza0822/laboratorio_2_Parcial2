﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases
{
    public static class ExtensoraRandom
    {
        public static int GenerarRandom(this List<Serie> lista, int maximo)
        {
            Random random = new Random();

            int numeroRandom = random.Next(0, maximo);

            return numeroRandom;
        }
    }
}
