﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases
{
    public class ManejadorBackLog
    {
        public delegate void DelegadoBackLog(Serie serie);

        public event DelegadoBackLog NuevaSerieParaVer;
        public void IniciarManejador(List<Serie> series)
        {
            Task moverSeries = Task.Run(() =>
            {
                MoverSeries(series);
            });

            moverSeries.Wait();
        }

        private async void MoverSeries(List<Serie> series){
            /*for(int i = 0; i < series.Count; i++)
            {
                int numRandom = series.GenerarRandom(series.Count);
                Thread.Sleep(1500);
                if (NuevaSerieParaVer != null)
                {
                    NuevaSerieParaVer.Invoke(series[numRandom]);
                }
            }*/
            while (true)
            {
                if(series.Count == 0)
                {
                    break;
                }
                int numRandom = series.GenerarRandom(series.Count);
                await Task.Delay(1500);
                if (NuevaSerieParaVer != null)
                {
                    NuevaSerieParaVer.Invoke(series[numRandom]);
                }
                //series.RemoveAt(numRandom);
            }
            /*for(int i = numRandom; i < series.Count; i++)
            {
                //Necesitamos ActualizarSerie
                
                if(NuevaSerieParaVer != null)
                {
                    NuevaSerieParaVer.Invoke(series[i]);
                }
            }*/

        }
    }
}
