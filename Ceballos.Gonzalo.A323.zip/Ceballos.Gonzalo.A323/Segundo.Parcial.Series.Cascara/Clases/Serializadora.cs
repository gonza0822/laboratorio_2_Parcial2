﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Clases
{
    public class Serializadora<T> : IGuardar<T>
    {
        public void Guardar(T item, string ruta)
        {
            StreamWriter streamWriter = new StreamWriter(ruta);
            try
            {
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
                xmlSerializer.Serialize(streamWriter, item);
            } catch (Exception ex)
            {
                throw new BackLogException("Error al serializar el item");
            } finally
            {
                streamWriter.Close();
                streamWriter.Dispose();
            }

        }

        void IGuardar<T>.Guardar(T item, string ruta)
        {
            StreamWriter streamWriter = new StreamWriter(ruta);
            try
            {
                JsonSerializerOptions opciones = new JsonSerializerOptions();
                opciones.WriteIndented = true;
                string jsonString = JsonSerializer.Serialize(item, opciones);
                streamWriter.Write(jsonString);
            } catch (Exception ex)
            {
                throw new BackLogException("Error al serializar el item");
            } finally
            {
                streamWriter.Close();
                streamWriter.Dispose();
            }
        }
    }
}
