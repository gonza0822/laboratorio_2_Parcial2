using Clases;

namespace Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        [ExpectedException(typeof(BackLogException))]
        public void verificarSerializacionJson()
        {
            Serializadora<Serie> serializadora = new Serializadora<Serie>();

            ((IGuardar<Serie>)serializadora).Guardar(new Serie(), "archivo.json");
        }

        [TestMethod]
        [ExpectedException(typeof(BackLogException))]
        public void verificarSerializacionXml()
        {
            Serializadora<Serie> serializadora = new Serializadora<Serie>();

            serializadora.Guardar(new Serie(), "archivo.json");
        }
    }
}